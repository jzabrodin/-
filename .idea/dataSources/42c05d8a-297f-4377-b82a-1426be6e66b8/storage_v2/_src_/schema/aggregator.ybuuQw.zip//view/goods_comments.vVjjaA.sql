create view goods_comments as
  select `aggregator`.`goods`.`ID`         AS `ID`,
         `aggregator`.`goods`.`name`       AS `name`,
         `aggregator`.`goods`.`image_path` AS `image_path`,
         `aggregator`.`reviews`.`comment`  AS `comment`
  from (`aggregator`.`reviews` left join `aggregator`.`goods` on ((`aggregator`.`goods`.`ID` =
                                                                   `aggregator`.`reviews`.`good_id`)));

