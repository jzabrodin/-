create view goods_rating as
  select `aggregator`.`reviews`.`good_id` AS `good_id`, count(`aggregator`.`reviews`.`comment`) AS `comments_quantity`
  from `aggregator`.`reviews`
  group by `aggregator`.`reviews`.`good_id`;

