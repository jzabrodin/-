create view goods_average_rating as
  select `aggregator`.`reviews`.`good_id` AS `good_id`, avg(`aggregator`.`reviews`.`rating`) AS `average_rating`
  from `aggregator`.`reviews`
  group by `aggregator`.`reviews`.`good_id`;

